/* Néon Bay : traductions (fr par défaut, en, es, pt).
   Le jeu est écrit en français ; chaque texte affiché passe par t(), qui cherche
   la traduction dans NB_DICT (js/i18n-dict.js) puis dans les modèles ci-dessous
   (textes qui contiennent des nombres ou des noms). */
window.NB_I18N = (() => {
  'use strict';
  const LANGS = ['fr', 'en', 'es', 'pt'];
  const NAMES = { fr: 'Français', en: 'English', es: 'Español', pt: 'Português' };
  let lang = 'fr';
  try {
    const saved = JSON.parse(localStorage.getItem('neonbay.save.v2') || '{}').lang;
    const nav = (navigator.language || 'fr').slice(0, 2).toLowerCase();
    lang = LANGS.includes(saved) ? saved : LANGS.includes(nav) ? nav : 'en';
  } catch (e) { lang = 'fr'; }
  const EXTRA = {
    "Néon Bay · 2 h du matin": { en: "Neon Bay · 2 a.m.", es: "Neon Bay · 2 de la madrugada", pt: "Neon Bay · 2 da manhã" },
    "Tu descends du bus avec quarante dollars et un numéro griffonné sur un ticket.": { en: "You step off the bus with forty dollars and a number scribbled on a ticket.", es: "Bajas del autobús con cuarenta dólares y un número garabateado en un boleto.", pt: "Você desce do ônibus com quarenta dólares e um número rabiscado num bilhete." },
    "Le cousin Dre": { en: "Cousin Dre", es: "El primo Dre", pt: "O primo Dre" },
    "Il tient trois coins de rue. Les Vipères veulent tout le reste, et la police regarde ailleurs… contre paiement.": { en: "He runs three street corners. The Vipers want everything else, and the cops look the other way… for a price.", es: "Controla tres esquinas. Las Víboras quieren todo lo demás, y la policía mira hacia otro lado… por un precio.", pt: "Ele comanda três esquinas. As Víboras querem todo o resto, e a polícia finge que não vê… por um preço." },
    "La règle": { en: "The rule", es: "La regla", pt: "A regra" },
    "Ici, on monte en rendant des services. Livrer, voler, escorter, disparaître dans les tunnels.": { en: "Here, you rise by doing favors. Deliver, steal, escort, vanish into the tunnels.", es: "Aquí se sube haciendo favores. Entregar, robar, escoltar, desaparecer por los túneles.", pt: "Aqui você sobe fazendo favores. Entregar, roubar, escoltar, sumir pelos túneis." },
    "Au-delà de la baie": { en: "Beyond the bay", es: "Más allá de la bahía", pt: "Além da baía" },
    "Porto Lumi, Sierra Verde, Morro Azul. Chaque ville a ses gangs, ses règles et ses flics à acheter.": { en: "Porto Lumi, Sierra Verde, Morro Azul. Every city has its gangs, its rules and its cops for sale.", es: "Porto Lumi, Sierra Verde, Morro Azul. Cada ciudad tiene sus pandillas, sus reglas y sus policías comprables.", pt: "Porto Lumi, Sierra Verde, Morro Azul. Cada cidade tem suas gangues, suas regras e seus policiais à venda." },
    "Trente nuits": { en: "Thirty nights", es: "Treinta noches", pt: "Trinta noites" },
    "Une seule question : jusqu’où tu montes ?": { en: "Just one question: how high will you rise?", es: "Una sola pregunta: ¿hasta dónde vas a subir?", pt: "Uma só pergunta: até onde você vai subir?" },
    "Une histoire de crime en 30 nuits, de Néon Bay aux favelas de Morro Azul.": { en: "A crime story in 30 nights, from Neon Bay to the favelas of Morro Azul.", es: "Una historia de crimen en 30 noches, de Neon Bay a las favelas de Morro Azul.", pt: "Uma história de crime em 30 noites, de Neon Bay às favelas do Morro Azul." },
    "Commencer l'histoire": { en: "Start the story", es: "Empezar la historia", pt: "Começar a história" },
    "Passer l'introduction": { en: "Skip intro", es: "Saltar la introducción", pt: "Pular a introdução" },
    "Passer ›": { en: "Skip ›", es: "Saltar ›", pt: "Pular ›" },
    "Introduction": { en: "Intro", es: "Introducción", pt: "Introdução" },
    "Niveau 1 · Nouveau en ville": { en: "Level 1 · New in town", es: "Nivel 1 · Nuevo en la ciudad", pt: "Nível 1 · Novo na cidade" },
    'les gardiens': { en: 'the guards', es: 'los guardias', pt: 'os guardas' },
    'Évasion': { en: 'Jailbreak', es: 'Fuga', pt: 'Fuga' }, 'Libérateur': { en: 'Liberator', es: 'Libertador', pt: 'Libertador' }, 'Alarme ! Neutralise les gardiens': { en: 'Alarm! Take out the guards', es: '¡Alarma! Neutraliza a los guardias', pt: 'Alarme! Neutralize os guardas' },
    'Voix off activée': { en: 'Voice-over on', es: 'Voz en off activada', pt: 'Narração ativada' },
    'Gratuit': { en: 'Free', es: 'Gratis', pt: 'Grátis' }, 'Gratuit si tu réussis :': { en: 'Free if you complete:', es: 'Gratis si completas:', pt: 'Grátis se você concluir:' }, 'Arme gagnée gratuitement': { en: 'Weapon earned for free', es: 'Arma ganada gratis', pt: 'Arma ganha de graça' },
    'Recommencer depuis le début': { en: 'Start over', es: 'Empezar de nuevo', pt: 'Recomeçar do início' },
    'Entraînement': { en: 'Training', es: 'Entrenamiento', pt: 'Treino' }, 'Endurance': { en: 'Stamina', es: 'Resistencia', pt: 'Resistência' }, 'Tir': { en: 'Shooting', es: 'Puntería', pt: 'Mira' }, 'Force': { en: 'Strength', es: 'Fuerza', pt: 'Força' },
    'Facile': { en: 'Easy', es: 'Fácil', pt: 'Fácil' }, 'Normal': { en: 'Normal', es: 'Normal', pt: 'Normal' }, 'Difficile': { en: 'Hard', es: 'Difícil', pt: 'Difícil' }, 'Légende': { en: 'Legend', es: 'Leyenda', pt: 'Lenda' },
    '+15 santé max par séance': { en: '+15 max health per session', es: '+15 de salud máxima por sesión', pt: '+15 de saúde máxima por sessão' },
    'Tirs plus précis (-12 %) et rechargement plus rapide (-8 %)': { en: 'More accurate shots (-12%) and faster reloads (-8%)', es: 'Disparos más precisos (-12 %) y recarga más rápida (-8 %)', pt: 'Tiros mais precisos (-12%) e recarga mais rápida (-8%)' },
    'Coups de poing +25 % et dégâts reçus -5 %': { en: 'Punches +25% and damage taken -5%', es: 'Puñetazos +25 % y daño recibido -5 %', pt: 'Socos +25% e dano recebido -5%' },
    'Mitrailleuse lourde': { en: 'Heavy machine gun', es: 'Ametralladora pesada', pt: 'Metralhadora pesada' }, 'Lance-grenades': { en: 'Grenade launcher', es: 'Lanzagranadas', pt: 'Lança-granadas' }, 'Fusil à impulsion': { en: 'Pulse rifle', es: 'Rifle de pulsos', pt: 'Rifle de pulso' },
    'Gros chargeur, gros dégâts. Touche 9.': { en: 'Big magazine, big damage. Key 9.', es: 'Gran cargador, gran daño. Tecla 9.', pt: 'Pente grande, dano grande. Tecla 9.' },
    'Six explosions à la suite. Touche 0.': { en: 'Six explosions in a row. Key 0.', es: 'Seis explosiones seguidas. Tecla 0.', pt: 'Seis explosões seguidas. Tecla 0.' },
    'Prototype ultime : 260 dégâts par tir.': { en: 'Ultimate prototype: 260 damage per shot.', es: 'Prototipo definitivo: 260 de daño por disparo.', pt: 'Protótipo definitivo: 260 de dano por tiro.' },
    'Exosquelette': { en: 'Exoskeleton', es: 'Exoesqueleto', pt: 'Exoesqueleto' }, 'Armure lourde': { en: 'Heavy armor', es: 'Armadura pesada', pt: 'Armadura pesada' },
    '250 points d’armure.': { en: '250 armor points.', es: '250 puntos de armadura.', pt: '250 pontos de armadura.' }, '400 points d’armure : presque un tank.': { en: '400 armor points: almost a tank.', es: '400 puntos de armadura: casi un tanque.', pt: '400 pontos de armadura: quase um tanque.' },
    'Jouer': { en: 'Play', es: 'Jugar', pt: 'Jogar' },
    'Continuer': { en: 'Continue', es: 'Continuar', pt: 'Continuar' },
    '+50 santé (touche H). Max 5.': { en: '+50 health (H key). Max 5.', es: '+50 de salud (tecla H). Máx. 5.', pt: '+50 de saúde (tecla H). Máx. 5.' },
    "Tu as aimé ? La suite t'attend.": { en: 'Enjoyed it? The rest is waiting.', es: '¿Te gustó? Lo mejor está por venir.', pt: 'Curtiu? O resto te espera.' },
    "Le lien de paiement n'est pas encore configuré (SHOP_CONFIG.buyUrl dans js/data.js).": { en: 'Purchases are not available yet.', es: 'Las compras aún no están disponibles.', pt: 'As compras ainda não estão disponíveis.' },
    'Aide activée : plus de temps et ennemis moins dangereux': { en: 'Assist on: more time and weaker enemies', es: 'Ayuda activada: más tiempo y enemigos menos peligrosos', pt: 'Ajuda ativada: mais tempo e inimigos menos perigosos' },
    'Qualité graphique réduite pour plus de fluidité': { en: 'Graphics quality lowered for smoother play', es: 'Calidad gráfica reducida para más fluidez', pt: 'Qualidade gráfica reduzida para mais fluidez' },
    'Haute': { en: 'High', es: 'Alta', pt: 'Alta' }, 'Moyenne': { en: 'Medium', es: 'Media', pt: 'Média' }, 'Basse': { en: 'Low', es: 'Baja', pt: 'Baixa' },
    'glisse pour viser': { en: 'slide to aim', es: 'desliza para apuntar', pt: 'deslize para mirar' },
    'frein à main': { en: 'handbrake', es: 'freno de mano', pt: 'freio de mão' },
    'FREIN': { en: 'BRAKE', es: 'FRENO', pt: 'FREIO' }, 'RECHARGE': { en: 'RELOAD', es: 'RECARGA', pt: 'RECARGA' },
    'DESCENDRE': { en: 'EXIT', es: 'BAJAR', pt: 'SAIR' }, 'MONTER': { en: 'ENTER', es: 'SUBIR', pt: 'ENTRAR' }, 'PAYER': { en: 'PAY', es: 'PAGAR', pt: 'PAGAR' },
    'PAYER FLICS': { en: 'PAY COPS', es: 'PAGAR POLIS', pt: 'PAGAR POLÍCIA' },
    'Manette connectée': { en: 'Controller connected', es: 'Mando conectado', pt: 'Controle conectado' },
    'Tourne ton téléphone': { en: 'Turn your phone', es: 'Gira tu teléfono', pt: 'Gire o celular' },
    "Néon Bay se joue à l'horizontale, avec un pouce de chaque côté.": { en: 'Néon Bay is played in landscape, one thumb on each side.', es: 'Néon Bay se juega en horizontal, con un pulgar a cada lado.', pt: 'Néon Bay se joga na horizontal, com um polegar de cada lado.' },
    'Jouer en vertical quand même': { en: 'Play in portrait anyway', es: 'Jugar en vertical de todos modos', pt: 'Jogar na vertical mesmo assim' },
    'Photo à partager': { en: 'Share a photo', es: 'Foto para compartir', pt: 'Foto para compartilhar' },
    'Regarde ma partie de Néon Bay !': { en: 'Check out my Néon Bay run!', es: '¡Mira mi partida de Néon Bay!', pt: 'Olha minha partida de Néon Bay!' },
    'Photo enregistrée': { en: 'Photo saved', es: 'Foto guardada', pt: 'Foto salva' }, 'Photo impossible ici': { en: 'Photos aren\u2019t available here', es: 'Aquí no se pueden hacer fotos', pt: 'Foto indisponível aqui' },
    'Pause conseillée': { en: 'Time for a break', es: 'Pausa recomendada', pt: 'Pausa recomendada' },
    "Comme au volant : une pause toutes les heures, c'est mieux. Lève-toi, bois un verre d'eau, repose tes yeux quelques minutes. Ta partie t'attend.": { en: 'Like when driving: a break every hour is a good idea. Stand up, drink some water, rest your eyes for a few minutes. Your game will be waiting.', es: 'Como al volante: una pausa cada hora es lo mejor. Levántate, bebe agua y descansa la vista unos minutos. Tu partida te espera.', pt: 'Como no volante: uma pausa a cada hora é o ideal. Levante, beba água e descanse os olhos alguns minutos. Seu jogo te espera.' },
    'Faire une pause': { en: 'Take a break', es: 'Hacer una pausa', pt: 'Fazer uma pausa' }, 'Continuer encore un peu': { en: 'Keep playing a bit', es: 'Seguir un poco más', pt: 'Continuar mais um pouco' },
    'Graffeur': { en: 'Tagger', es: 'Grafitero', pt: 'Grafiteiro' }, 'Chasseur de tags': { en: 'Tag hunter', es: 'Cazador de grafitis', pt: 'Caçador de grafites' },
    'Radio coupée': { en: 'Radio off', es: 'Radio apagada', pt: 'Rádio desligado' }, 'RADIO': { en: 'RADIO', es: 'RADIO', pt: 'RÁDIO' },
    'Atelier': { en: 'Workshop', es: 'Taller', pt: 'Oficina' }, 'Dégâts': { en: 'Damage', es: 'Daño', pt: 'Dano' }, 'Chargeur': { en: 'Magazine', es: 'Cargador', pt: 'Pente' }, 'Précision': { en: 'Accuracy', es: 'Precisión', pt: 'Precisão' }, 'Peinture': { en: 'Paint', es: 'Pintura', pt: 'Pintura' }, 'Maximum': { en: 'Maxed', es: 'Máximo', pt: 'Máximo' },
    'Noir mat': { en: 'Matte black', es: 'Negro mate', pt: 'Preto fosco' }, 'Chrome': { en: 'Chrome', es: 'Cromo', pt: 'Cromado' }, 'Camouflage': { en: 'Camo', es: 'Camuflaje', pt: 'Camuflado' }, 'Cyan néon': { en: 'Neon cyan', es: 'Cian neón', pt: 'Ciano neon' }, 'Or': { en: 'Gold', es: 'Oro', pt: 'Ouro' },
    'CIBLE': { en: 'LOCK', es: 'FIJAR', pt: 'MIRA' }, 'Cible verrouillée': { en: 'Target locked', es: 'Objetivo fijado', pt: 'Alvo travado' }, 'Aucune cible à portée': { en: 'No target in range', es: 'Ningún objetivo a tiro', pt: 'Nenhum alvo ao alcance' },
    'Corps': { en: 'Body', es: 'Cuerpo', pt: 'Corpo' }, 'Humain': { en: 'Human', es: 'Humano', pt: 'Humano' }, 'Robot animé': { en: 'Animated robot', es: 'Robot animado', pt: 'Robô animado' },
  };
  const dict = () => Object.assign({}, window.NB_DICT || {}, EXTRA);
  // [motif sur le texte français, { en, es, pt }] ; $1, $2… sont traduits à leur tour
  const P = [
    [/^Rejoins (.+)$/, { en: 'Go to $1', es: 'Ve a $1', pt: 'Vá até $1' }],
    [/^Livre la marchandise à (.+) en voiture$/, { en: 'Deliver the goods to $1 by car', es: 'Entrega la mercancía en $1 en coche', pt: 'Entregue a mercadoria em $1 de carro' }],
    [/^Récupère les valises près de (.+) \((\d+)\/(\d+)\)$/, { en: 'Grab the briefcases near $1 ($2/$3)', es: 'Recoge los maletines cerca de $1 ($2/$3)', pt: 'Pegue as maletas perto de $1 ($2/$3)' }],
    [/^Élimine (.+), chef de (.+)$/, { en: 'Take down $1, boss of $2', es: 'Acaba con $1, jefe de $2', pt: 'Derrube $1, chefe de $2' }],
    [/^Neutralise (.+) \((\d+) restants\)$/, { en: 'Take out $1 ($2 left)', es: 'Neutraliza a $1 ($2 restantes)', pt: 'Neutralize $1 ($2 restantes)' }],
    [/^Retrouve (.+)$/, { en: 'Find $1', es: 'Encuentra a $1', pt: 'Encontre $1' }],
    [/^Emmène (.+) à (.+) en vie$/, { en: 'Get $1 to $2 alive', es: 'Lleva a $1 a $2 con vida', pt: 'Leve $1 até $2 com vida' }],
    [/^Détruis le convoi de (.+) \((\d+) restants\)$/, { en: 'Destroy $1\u2019s convoy ($2 left)', es: 'Destruye el convoy de $1 ($2 restantes)', pt: 'Destrua o comboio de $1 ($2 restantes)' }],
    [/^Course : passe les checkpoints \((\d+)\/4\)$/, { en: 'Race: hit the checkpoints ($1/4)', es: 'Carrera: pasa los puntos de control ($1/4)', pt: 'Corrida: passe pelos checkpoints ($1/4)' }],
    [/^Va voir l’agent corrompu et donne-lui (.+) \(E\)$/, { en: 'Meet the corrupt cop and hand over $1 (E)', es: 'Ve a ver al agente corrupto y dale $1 (E)', pt: 'Encontre o policial corrupto e entregue $1 (E)' }],
    [/^(.+) \(monte dans une voiture : E\)$/, { en: '$1 (get in a car: E)', es: '$1 (súbete a un coche: E)', pt: '$1 (entre em um carro: E)' }],
    [/^Niveau (\d+) · (.+) · étape (\d+)\/10$/, { en: 'Level $1 · $2 · step $3/10', es: 'Nivel $1 · $2 · etapa $3/10', pt: 'Nível $1 · $2 · etapa $3/10' }],
    [/^Niveau (\d+) · (.+)$/, { en: 'Level $1 · $2', es: 'Nivel $1 · $2', pt: 'Nível $1 · $2' }],
    [/^Niveau (\d+) : (.+)$/, { en: 'Level $1: $2', es: 'Nivel $1: $2', pt: 'Nível $1: $2' }],
    [/^Niveau (\d+) terminé$/, { en: 'Level $1 complete', es: 'Nivel $1 completado', pt: 'Nível $1 concluído' }],
    [/^Niveau (\d+)$/, { en: 'Level $1', es: 'Nivel $1', pt: 'Nível $1' }],
    [/^(.+) · (.+) · Niveau (\d+)\/30$/, { en: '$1 · $2 · Level $3/30', es: '$1 · $2 · Nivel $3/30', pt: '$1 · $2 · Nível $3/30' }],
    [/^(.+) · niveaux (\d+)–(\d+)$/, { en: '$1 · levels $2–$3', es: '$1 · niveles $2–$3', pt: '$1 · níveis $2–$3' }],
    [/^Étape (\d+)\/10 · (.+)$/, { en: 'Step $1/10 · $2', es: 'Etapa $1/10 · $2', pt: 'Etapa $1/10 · $2' }],
    [/^Étape (\d+)\/10 réussie · \+(.+)$/, { en: 'Step $1/10 done · +$2', es: 'Etapa $1/10 superada · +$2', pt: 'Etapa $1/10 concluída · +$2' }],
    [/^Mission réussie ! \+(.+)$/, { en: 'Mission complete! +$1', es: '¡Misión cumplida! +$1', pt: 'Missão cumprida! +$1' }],
    [/^Point (\d+)\/(\d+)$/, { en: 'Point $1/$2', es: 'Punto $1/$2', pt: 'Ponto $1/$2' }],
    [/^Checkpoint (\d+)\/4$/, { en: 'Checkpoint $1/4', es: 'Punto de control $1/4', pt: 'Checkpoint $1/4' }],
    [/^Soins (\d+) · Nitro (\d+)$/, { en: 'Medkits $1 · Nitro $2', es: 'Botiquines $1 · Nitro $2', pt: 'Kits $1 · Nitro $2' }],
    [/^Agents soudoyés \(−(.+)\)$/, { en: 'Cops bribed (−$1)', es: 'Agentes sobornados (−$1)', pt: 'Policiais subornados (−$1)' }],
    [/^Voiture repeinte · police semée \(−(.+)\)$/, { en: 'Car repainted · cops lost (−$1)', es: 'Coche repintado · policía despistada (−$1)', pt: 'Carro repintado · polícia despistada (−$1)' }],
    [/^Il faut (.+) pour repeindre$/, { en: 'You need $1 to repaint', es: 'Necesitas $1 para repintar', pt: 'Você precisa de $1 para repintar' }],
    [/^Il te faut (.+) pour soudoyer les agents$/, { en: 'You need $1 to bribe the cops', es: 'Necesitas $1 para sobornar a los agentes', pt: 'Você precisa de $1 para subornar a polícia' }],
    [/^B : soudoyer les agents \((.+)\)$/, { en: 'B: bribe the cops ($1)', es: 'B: sobornar a los agentes ($1)', pt: 'B: subornar a polícia ($1)' }],
    [/^E : payer l’agent \((.+)\)$/, { en: 'E: pay the cop ($1)', es: 'E: pagar al agente ($1)', pt: 'E: pagar o policial ($1)' }],
    [/^L’agent empoche (.+) et te donne le tuyau$/, { en: 'The cop pockets $1 and gives you the tip', es: 'El agente se embolsa $1 y te pasa el dato', pt: 'O policial embolsa $1 e te passa a dica' }],
    [/^Pas assez d’argent : l’agent prend (.+) et te balance !$/, { en: 'Not enough cash: the cop takes $1 and rats you out!', es: '¡No te alcanza: el agente se queda $1 y te delata!', pt: 'Dinheiro insuficiente: o policial pega $1 e te dedura!' }],
    [/^Termine le niveau (\d+) d’abord$/, { en: 'Finish level $1 first', es: 'Termina primero el nivel $1', pt: 'Termine o nível $1 primeiro' }],
    [/^(.+) est tombé !$/, { en: '$1 is down!', es: '¡$1 ha caído!', pt: '$1 caiu!' }],
    [/^(.+) te suit$/, { en: '$1 is following you', es: '$1 te sigue', pt: '$1 está te seguindo' }],
    [/^(.+) monte dans la voiture$/, { en: '$1 gets in the car', es: '$1 se sube al coche', pt: '$1 entra no carro' }],
    [/^(.+) n’a pas survécu$/, { en: '$1 didn\u2019t make it', es: '$1 no sobrevivió', pt: '$1 não sobreviveu' }],
    [/^\+ (.+) par étape$/, { en: '+ $1 per step', es: '+ $1 por etapa', pt: '+ $1 por etapa' }],
    [/^Conseillé : (.+)$/, { en: 'Recommended: $1', es: 'Recomendado: $1', pt: 'Recomendado: $1' }],
    [/^Rapide : moins de (\d+) min (\d+)$/, { en: 'Fast: under $1 min $2', es: 'Rápido: menos de $1 min $2', pt: 'Rápido: menos de $1 min $2' }],
    [/^Propre : santé ≥ 60 % et 3 passants K\.O\. maximum \((\d+)\)$/, { en: 'Clean: health ≥ 60% and 3 bystanders K.O. max ($1)', es: 'Limpio: salud ≥ 60 % y máximo 3 transeúntes K.O. ($1)', pt: 'Limpo: saúde ≥ 60% e no máximo 3 pedestres nocauteados ($1)' }],
    [/^(\d+) min (\d+)$/, { en: '$1 min $2', es: '$1 min $2', pt: '$1 min $2' }],
    [/^Nouveau dans la boutique : (.+)$/, { en: 'New in the shop: $1', es: 'Nuevo en la tienda: $1', pt: 'Novo na loja: $1' }],
    [/^(\d+)\/30 niveaux$/, { en: '$1/30 levels', es: '$1/30 niveles', pt: '$1/30 níveis' }],
    [/^(\d+)\/(\d+) succès$/, { en: '$1/$2 achievements', es: '$1/$2 logros', pt: '$1/$2 conquistas' }],
    [/^Musique : (oui|non)$/, { en: 'Music: $1', es: 'Música: $1', pt: 'Música: $1' }],
    [/^Bruitages : (oui|non)$/, { en: 'Sound effects: $1', es: 'Efectos: $1', pt: 'Efeitos: $1' }],
    [/^Vibrations : (oui|non)$/, { en: 'Vibration: $1', es: 'Vibración: $1', pt: 'Vibração: $1' }],
    [/^Caméra : (.+)$/, { en: 'Camera: $1', es: 'Cámara: $1', pt: 'Câmera: $1' }],
    [/^Jeu complet · (.+)$/, { en: 'Full game · $1', es: 'Juego completo · $1', pt: 'Jogo completo · $1' }],
    [/^Débloquer le jeu complet · (.+)$/, { en: 'Unlock the full game · $1', es: 'Desbloquear el juego completo · $1', pt: 'Desbloquear o jogo completo · $1' }],
    [/^Série : (\d+) jours? · \+(.+) chacun$/, { en: 'Streak: $1 day(s) · +$2 each', es: 'Racha: $1 día(s) · +$2 cada uno', pt: 'Sequência: $1 dia(s) · +$2 cada' }],
    [/^\+(.+) chacun$/, { en: '+$1 each', es: '+$1 cada uno', pt: '+$1 cada' }],
    [/^Vole (\d+) voitures$/, { en: 'Steal $1 cars', es: 'Roba $1 coches', pt: 'Roube $1 carros' }],
    [/^Sème la police (\d+) fois$/, { en: 'Lose the cops $1 times', es: 'Despista a la policía $1 veces', pt: 'Despiste a polícia $1 vezes' }],
    [/^Neutralise (\d+) ennemis$/, { en: 'Take out $1 enemies', es: 'Neutraliza a $1 enemigos', pt: 'Neutralize $1 inimigos' }],
    [/^Prends (\d+) tunnels$/, { en: 'Take $1 tunnels', es: 'Usa $1 túneles', pt: 'Use $1 túneis' }],
    [/^Soudoie la police (\d+) fois$/, { en: 'Bribe the cops $1 times', es: 'Soborna a la policía $1 veces', pt: 'Suborne a polícia $1 vezes' }],
    [/^Fais exploser (\d+) véhicules$/, { en: 'Blow up $1 vehicles', es: 'Haz explotar $1 vehículos', pt: 'Exploda $1 veículos' }],
    [/^Ramasse (.+) \$ par terre$/, { en: 'Pick up $$1 from the street', es: 'Recoge $1 $ del suelo', pt: 'Pegue $1 $ do chão' }],
    [/^Termine (\d+) niveaux différents$/, { en: 'Complete $1 different levels', es: 'Completa $1 niveles distintos', pt: 'Conclua $1 níveis diferentes' }],
    [/^Termine (\d+) niveau\(x\)$/, { en: 'Complete $1 level(s)', es: 'Completa $1 nivel(es)', pt: 'Conclua $1 nível(is)' }],
    [/^Obtiens 3 étoiles sur (\d+) niveaux$/, { en: 'Get 3 stars on $1 levels', es: 'Consigue 3 estrellas en $1 niveles', pt: 'Ganhe 3 estrelas em $1 níveis' }],
    [/^(\d+) étoiles sur 3$/, { en: '$1 stars out of 3', es: '$1 estrellas de 3', pt: '$1 estrelas de 3' }],
    [/^(.+) · recharge…$/, { en: '$1 · reloading…', es: '$1 · recargando…', pt: '$1 · recarregando…' }],
    [/^(\d\d:\d\d) · pluie$/, { en: '$1 · rain', es: '$1 · lluvia', pt: '$1 · chuva' }],
    [/^(.+)\. L'argent gagné pendant la tentative est conservé \((.+)\)\.$/, { en: '$1. The money earned during this attempt is kept ($2).', es: '$1. Conservas el dinero ganado en este intento ($2).', pt: '$1. O dinheiro ganho nesta tentativa fica com você ($2).' }],
    [/^Difficulté : (.+)$/, { en: 'Difficulty: $1', es: 'Dificultad: $1', pt: 'Dificuldade: $1' }],
    [/^S'entraîner · (.+)$/, { en: 'Train · $1', es: 'Entrenar · $1', pt: 'Treinar · $1' }],
    [/^(Endurance|Tir|Force) · (\d)\/5$/, { en: '$1 · $2/5', es: '$1 · $2/5', pt: '$1 · $2/5' }],
    [/^Séance terminée · (Endurance|Tir|Force) (\d)\/5$/, { en: 'Session done · $1 $2/5', es: 'Sesión terminada · $1 $2/5', pt: 'Treino concluído · $1 $2/5' }],
    [/^Chaque séance te rend plus fort pour toujours\. Santé max : (\d+)\.$/, { en: 'Every session makes you stronger for good. Max health: $1.', es: 'Cada sesión te hace más fuerte para siempre. Salud máxima: $1.', pt: 'Cada treino te deixa mais forte para sempre. Saúde máxima: $1.' }],
    [/^Reprendre à l'étape (\d+)$/, { en: 'Resume at step $1', es: 'Continuar en la etapa $1', pt: 'Continuar na etapa $1' }],
    [/^Reprise à l’étape (\d+)$/, { en: 'Resuming at step $1', es: 'Reanudando en la etapa $1', pt: 'Retomando na etapa $1' }],
    [/^Voix off : (oui|non)$/, { en: 'Voice-over: $1', es: 'Voz en off: $1', pt: 'Narração: $1' }],
    [/^Fais évader (.+) de la prison$/, { en: 'Break $1 out of prison', es: 'Saca a $1 de la cárcel', pt: 'Tire $1 da prisão' }],
    [/^Neutralise les gardiens \((\d+) restants\)$/, { en: 'Take out the guards ($1 left)', es: 'Neutraliza a los guardias (quedan $1)', pt: 'Neutralize os guardas (restam $1)' }],
    [/^Emmène (.+) en lieu sûr avant les renforts$/, { en: 'Get $1 to safety before backup arrives', es: 'Lleva a $1 a un lugar seguro antes de los refuerzos', pt: 'Leve $1 para um lugar seguro antes dos reforços' }],
    [/^(.+) est libre : emmène-le$/, { en: '$1 is free: get him out', es: '$1 está libre: sácalo de aquí', pt: '$1 está livre: tire ele daqui' }],
    [/^Fais évader (\d+) prisonniers$/, { en: 'Break out $1 prisoners', es: 'Libera a $1 prisioneros', pt: 'Liberte $1 prisioneiros' }],
    [/^Qualité : (.+)$/, { en: 'Quality: $1', es: 'Calidad: $1', pt: 'Qualidade: $1' }],
    [/^Auto \((.+)\)$/, { en: 'Auto ($1)', es: 'Auto ($1)', pt: 'Auto ($1)' }],
    [/^Traverser les immeubles : (oui|non)$/, { en: 'Walk through buildings: $1', es: 'Atravesar edificios: $1', pt: 'Atravessar prédios: $1' }],
    [/^Ça fait (\d+) heures? que tu joues$/, { en: 'You\u2019ve been playing for $1 hour(s)', es: 'Llevas $1 hora(s) jugando', pt: 'Você está jogando há $1 hora(s)' }],
    [/^Tag secret (\d+)\/12 · \+(.+)$/, { en: 'Secret tag $1/12 · +$2', es: 'Grafiti secreto $1/12 · +$2', pt: 'Grafite secreto $1/12 · +$2' }],
    [/^Trouve (\d+) tags secrets$/, { en: 'Find $1 secret tags', es: 'Encuentra $1 grafitis secretos', pt: 'Encontre $1 grafites secretos' }],
    [/^(\d+)\/48 tags secrets$/, { en: '$1/48 secret tags', es: '$1/48 grafitis secretos', pt: '$1/48 grafites secretos' }],
    [/^Radio : (.+)$/, { en: 'Radio: $1', es: 'Radio: $1', pt: 'Rádio: $1' }],
    [/^Améliorer · (.+)$/, { en: 'Upgrade · $1', es: 'Mejorar · $1', pt: 'Melhorar · $1' }],
    [/^Doubler le bonus \(vidéo\) · \+(.+)$/, { en: 'Double the bonus (video) · +$1', es: 'Duplica el bonus (vídeo) · +$1', pt: 'Dobre o bônus (vídeo) · +$1' }],
    [/^Achat non abouti : (.+)$/, { en: 'Purchase failed: $1', es: 'Compra no completada: $1', pt: 'Compra não concluída: $1' }],
  ];
  const OUI = { oui: { en: 'on', es: 'sí', pt: 'sim' }, non: { en: 'off', es: 'no', pt: 'não' } };
  // contractions : es « de el » -> « del », pt « em o » -> « no », etc.
  function fix(x) {
    if (lang === 'es') return x.replace(/\bde el\b/g, 'del').replace(/\ba el\b/g, 'al').replace(/\bDe el\b/g, 'Del');
    if (lang === 'pt') return x.replace(/\bem o\b/g, 'no').replace(/\bem a\b/g, 'na').replace(/\bem os\b/g, 'nos').replace(/\bem as\b/g, 'nas').replace(/\bde o\b/g, 'do').replace(/\bde a\b/g, 'da').replace(/\bde os\b/g, 'dos').replace(/\bde as\b/g, 'das').replace(/\baté o\b/g, 'até o');
    return x;
  }
  function t(s) {
    if (lang === 'fr' || s == null) return s;
    s = String(s);
    const key = s.replace(/\s+/g, ' ').trim();
    if (!key) return s;
    if (OUI[key]) return OUI[key][lang];
    const d = dict()[key];
    if (d && d[lang]) return s.replace(s.trim(), d[lang]);
    for (const [re, tp] of P) {
      const m = key.match(re);
      if (m) { let out = tp[lang]; for (let i = m.length - 1; i >= 1; i--) out = out.split('$' + i).join(t(m[i])); return s.replace(s.trim(), fix(out)); }
    }
    return s;
  }
  function dom(root) {
    if (lang === 'fr' || !root) return;
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    const nodes = []; while (w.nextNode()) nodes.push(w.currentNode);
    for (const n of nodes) { const v = n.nodeValue; if (/[A-Za-zÀ-ÿ]/.test(v)) { const r = t(v); if (r !== v) n.nodeValue = r; } }
    root.querySelectorAll('[placeholder],[aria-label],[title]').forEach(el => { for (const a of ['placeholder', 'aria-label', 'title']) { const v = el.getAttribute(a); if (v && /[A-Za-zÀ-ÿ]{2}/.test(v)) el.setAttribute(a, t(v)); } });
  }
  return { t, dom, LANGS, NAMES, get lang() { return lang; }, set(l) { if (LANGS.includes(l)) lang = l; document.documentElement.lang = lang; } };
})();
